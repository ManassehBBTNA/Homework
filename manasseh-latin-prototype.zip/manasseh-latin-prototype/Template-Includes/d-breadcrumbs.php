<div id="breadcrumb-holder" class="tna-breadcrumb">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="breadcrumbs"><a href="http://www.nationalarchives.gov.uk/">Home</a>
                    <span class="sep">&gt;</span> <span>BREAD</span>
                    <span class="sep">&gt;</span> <span>CRUMBS</span>
                </div>
                <!-- .breadcrumbs -->
            </div>
        </div>
    </div>
</div>