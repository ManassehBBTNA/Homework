<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta content="initial-scale = 1.0" name="viewport">
<link rel='stylesheet' id='tna-styles-css'  href='./styles/base-sass.css' type='text/css' media='all' />
<link rel='stylesheet' id='tna-styles-css'  href='./styles/new-styles.css' type='text/css' media='all' />
<link rel='stylesheet' id='tna-google-fonts-css'  href='https://fonts.googleapis.com/css?family=Open+Sans%3A400%2C700%2C400italic%2C700italic%7CBitter&#038;ver=4.4.1' type='text/css' media='all' />
