<div class="row">
    <div class="col-md-12">
        <article>
            <div class="entry-header">
                <h2>
                    OTHER BANNER BUT SMALLER THIS TIME
                </h2>
            </div>
            <div class="entry-content clearfix">
                CONTENT
            </div>
        </article>
    </div>
</div>