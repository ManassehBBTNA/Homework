<div class="row">
    <div class="col-md-12 banner">
        <article>
            <div class="entry-header">
                <h1>
                    LESSON
                </h1>
            </div>
            <div class="entry-content clearfix breather-top">
               BLURB

            </div>
        </article>
    </div>
</div>