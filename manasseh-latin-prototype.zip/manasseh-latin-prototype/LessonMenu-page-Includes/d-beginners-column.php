<div class="col-md-6 col-xs-12">
    <article>
        <div class="entry-header">
            <h2>Beginners' Lessons</h2>
        </div>
        <div class="entry-content clearfix">
        	<ul class="child">
                <li><a href="./Lesson-1.php?">1. Introduction to verbs</a></li> <!--make a lesson 1 or the template page for a leeson and add the link here-->
                <li><a href="./!!!!!.php?">7. Third declension nouns and adjectives</a></li>
                <li><a href="./!!!!!.php?">2. Introction to nouns</a></li>
                <li><a href="./!!!!!.php?">8. Prepositions; possession</a></li>
                <li><a href="./!!!!!.php?">3. Second declension nouns</a></li>
                <li><a href="./Lesson-9.php?">9. Using the word list for verbs</a></li>
                <li><a href="./!!!!!.php?">4. Non; Second conjugation verbs; numbers</a></li>
                <li><a href="./!!!!!.php?">10. Qui, que, quod; the family</a></li>
                <li><a href="./!!!!!.php?">5. First and second declension adjectives; ego and nos</a></li>
                <li><a href="./!!!!!.php?">11. Fourth and fifth declension nouns; days of the week</a></li>
                <li><a href="./!!!!!.php?">6. Hic, hec, hoc; third and fourth conjugation verbs</a></li>
                <li><a href="./!!!!!.php?">12. Adverbs; numbers and dates; months; useful phrases; dating clauses</a></li>
            </ul>
        </div>
    </article>

</div>