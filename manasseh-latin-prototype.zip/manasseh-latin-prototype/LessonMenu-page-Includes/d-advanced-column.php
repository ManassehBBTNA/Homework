<div class="col-md-6 col-xs-12">
    <article>
        <div class="entry-header">
            <h2>Advanced Lessons</h2>
        </div>
        <div class="entry-content clearfix">
        	<ul class="child">
                <li><a href="./Lesson-1.php?">1. Imperfect tense</a></li> <!--make a lesson 1 or the template page for a leeson and add the link here-->
                <li><a href="./!!!!!.php?">7. Participles - present, past and future</a></li>
                <li><a href="./!!!!!.php?">2. Pluperfect tense</a></li>
                <li><a href="./!!!!!.php?">8. Comparison of adjectives and adverbs</a></li>
                <li><a href="./!!!!!.php?">3. Future simple tense</a></li>
                <li><a href="./Lesson-9.php?">9. Subjunctive</a></li>
                <li><a href="./!!!!!.php?">4. Future perfect tense</a></li>
                <li><a href="./!!!!!.php?">10. Deponent and semi-deponent verbs</a></li>
                <li><a href="./!!!!!.php?">5. Pronouns</a></li>
                <li><a href="./!!!!!.php?">11. Gerunds and Gerundives</a></li>
                <li><a href="./!!!!!.php?">6. Passive verbs</a></li>
                <li><a href="./!!!!!.php?">12. Infinitives; accusative and infinitive clause</a></li>
            </ul>
        </div>
    </article>
</div>