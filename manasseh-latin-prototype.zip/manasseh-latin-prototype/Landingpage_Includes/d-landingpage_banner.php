<div class="row level-one" role="banner">
    <div class="col-md-12">
        <article class="banner feature-img feature-img-bg" style="background-image: url(
                        ./img/domesdayBG.jpg);">
            <div class="entry-header">
                <h1>Learn Latin 1086 - 1733</h1>
            </div>
        </article>
    </div>
</div>