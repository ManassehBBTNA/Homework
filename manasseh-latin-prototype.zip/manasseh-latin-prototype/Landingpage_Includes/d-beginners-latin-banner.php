<div class="col-md-12">
    <article>
        <div class="entry-header">
            <h2>
                Beginners' Latin:
            </h2>
        </div>
        <div class="entry-content clearfix">
            <ul class="child">
                <li><a href="./where_to_start_page.php?">Where to start</a></li>
                <li><a href="./Reference_page.php?">Reference page</a></li>
                <li><a href="./Activities_page.php?">Activities</a></li>
                <li><a href="./?">Futher practice</a></li>
                <li><a href="./LessonMenu_page.php?">Tutorials</a></li><!-- Link to lesson menu page-->
            </ul>
        </div>
    </article>
</div>