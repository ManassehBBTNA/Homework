<!DOCTYPE html>
	<head>
	<title>Reference</title>
		<?php
			/*add includes for the document head and header php */
		?>
	</head>
	<body>
		<?php
		/* add include for breadcrumbs here */
		?>
		<main id="primary" role="main" class="content-area">
			<div class="container">
				<?php
					/*add includes for banner and Landing page blurb here */
				?>
			</div>
        </main>
        <?php
        	/*add include for the newsletter */ 
        ?>
	</body>
	<footer id="footer" class="breather-top-bottom" role="contentinfo">
		<?php
		/* add include for footer here*/ 
		?>
	</footer>